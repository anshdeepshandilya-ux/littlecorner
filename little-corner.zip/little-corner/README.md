# Little Corners

Cute decor. Simple prices. Made your way.

A single-file shop for the Little Corners handmade decor brand (`index.html`): product pages, bag, custom-order form and the "Ask Little Corners AI" assistant.

## Run it
Open `index.html` in a browser, or host the folder on Netlify, Vercel or GitHub Pages.

## Edit products
In `index.html`, edit the `P` list (name, price, colour, photo, text) and the `TAGS` line (search words the assistant uses).

## Orders and enquiries
Sent to the shop email through formsubmit.co. Confirm the activation email from formsubmit once.

## AI assistant
Works with built-in rules. For a server-side AI, set `CHAT_ENDPOINT` in `index.html` to your function URL and keep the API key on the server only.
